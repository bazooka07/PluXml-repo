<div>
	<p>Ce plugin rajoute un bouton "Dupliquer" dans la page d'édition d'un article ou d'une page statique pour cloner ces éléments.</p>
	<p>Dans la liste des pages statiques, rajoute une option 'Dupliquer" pour la sélection et permet de cloner un lots de pages statiques.</p>
</div>
