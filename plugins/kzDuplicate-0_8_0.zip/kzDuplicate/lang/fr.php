<?php
$LANG = array(
	'L_DUPLICATE_BTN'	=> 'Dupliquer'
);
?>
