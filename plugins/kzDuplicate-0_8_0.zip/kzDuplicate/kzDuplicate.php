<?php
if(!defined('PLX_ROOT')) { exit; }

/**
 * kzDuplicate addon for PluXml
 * Duplicates an article or one or more static pages.
 *
 * Add a button for editing an article or a static page.
 * Otherwise, add an option for duplicating a batch of static pages in the listing.
 *
 * @author Jean-Pierre Pourrez (aka bazooka07)
 * @date 2019-03-10
 * */
class kzDuplicate extends plxPlugin {

	const FIELD_NAME = __CLASS__ . 'Btn';

	public function __construct($lang) {
		parent::__construct($lang);

		if(!defined('PLX_ADMIN')) { return; }

		/* -------- article --------- */
		parent::addHook('AdminArticlePostData', 'AdminArticlePostData');
		parent::addHook('AdminArticleParseData', 'AdminArticleParseData');
		parent::addHook('AdminArticleTop', 'AdminArticleTop');
		/* -------- only for static page and pages --------- */
		parent::addHook('AdminTopBottom', 'AdminTopBottom');
		/* ------- static page ------- */
		parent::addHook('plxAdminEditStatique', 'plxAdminEditStatique');
		parent::addHook('AdminStaticTop', 'AdminStaticTop');
		/* ------- static pages ------ */
		parent::addHook('plxAdminEditStatiquesUpdate', 'plxAdminEditStatiquesUpdate');
		parent::addHook('AdminStaticsTop', 'AdminStaticsTop');
		parent::addHook('AdminStaticsFoot', 'AdminStaticsFoot');
	}

	/* ================ Hooks ==================== */

	/* ----------- article ---------- */

	public function AdminArticlePostData() {
		if(!filter_has_var(INPUT_POST, self::FIELD_NAME)) { return; }
		echo <<< 'CODE'
<?php

if(!empty(trim($content))) {
	$artId = '0000';
	$title .= date(' (y-m-d H:i:s)');
	$author = $_SESSION['user'];
	$catId[] = 'draft';

	list($kzYear, $kzMonth, $kzDay, $kzTime) = explode('|', date('Y|m|d|H:i'));
	$date = array(
		'year'	=> $kzYear,
		'month'	=> $kzMonth,
		'day'	=> $kzDay,
		'time'	=> $kzTime
	);
	$date_creation = $date;
	$date_update = $date;

	$url = '';
}
?>
CODE;
	}

	public function AdminArticleParseData() {
		echo <<< 'CODE'
<?php
if(
	!empty($artId) and
	$artId != '0000' and
	!empty(trim($content)) and
	ob_start()
) {
	$kzArtDuplicate = true;
}
?>
CODE;
	}

	const ADMIN_ARTICLE_TOP_CODE = <<< 'ADMIN_ARTICLE_TOP_CODE'
<?php
if(!empty($kzArtDuplicate)) {
	echo preg_replace(
		'@(<input\b[^>]*\bname="update"[^>]*>)@',
		'<input type="submit" name="#FIELD_NAME#" value="#CAPTION#" />'."\n$1",
		ob_get_clean()
	);
}
?>
ADMIN_ARTICLE_TOP_CODE;

	public function AdminArticleTop() {
		echo strtr(
			self::ADMIN_ARTICLE_TOP_CODE,
			array(
				'#CAPTION#'		=> $this->getLang('L_DUPLICATE_BTN'),
				'#FIELD_NAME#'	=> self::FIELD_NAME
			)
		);
	}

	/* -------- only for static page and pages --------- */

	public function AdminTopBottom() {
		echo <<< 'CODE'
<?php
if(
	preg_match('@^core/admin/statiques?\.php@', $plxAdmin->path_url) and
	ob_start()
) {
	$kzStaticDuplicate = true;
}
?>
CODE;
	}

	/* --------- Static page ------------ */

	const PLXADMIN_EDITSTATIQUE_CODE = <<< 'PLXADMIN_EDITSTATIQUE_CODE'
<?php
if(!empty($content['#FIELD_NAME#'])) {
	foreach(array_keys($this->aStats) as $i=>$staticId) {
		$this->aStats[$staticId]['order'] = $i * 2;
	}
	$kzStaticIds = array_keys($this->aStats);
	rsort($kzStaticIds);
	$newStaticId = str_pad(intval($kzStaticIds[0]) + 1, 3, "0", STR_PAD_LEFT);
	$this->aStats[$newStaticId] = $this->aStats[$content['id']];

	$this->aStats[$newStaticId]['name'] .= date(' (Y-m-d H:i)');
	$this->aStats[$newStaticId]['url'] = plxUtils::title2url($this->aStats[$newStaticId]['name']);
	$this->aStats[$newStaticId]['date_update'] = date('YmdHi');
	$this->aStats[$newStaticId]['order']++;
	uasort($this->aStats, function($a, $b) { return $a['order'] - $b['order']; });

	$content['id'] = $newStaticId;
	$_POST['id'] = $newStaticId;
}
?>
PLXADMIN_EDITSTATIQUE_CODE;

	public function plxAdminEditStatique() {
		echo strtr(
			self::PLXADMIN_EDITSTATIQUE_CODE,
			array(
				'#FIELD_NAME#'	=> self::FIELD_NAME
			)
		);
	}

	const ADMIN_STATIC_TOP_CODE = <<< 'ADMIN_STATIC_TOP_CODE'
<?php
if(!empty($kzStaticDuplicate)) {
	echo preg_replace(
		'@(<input\b[^>]* type="submit"[^>]*>)@',
		'<input type="submit" name="#FIELD_NAME#" value="#CAPTION#" />'."\n$1",
		ob_get_clean()
	);
}
?>
ADMIN_STATIC_TOP_CODE;

	public function AdminStaticTop() {
		echo strtr(
			self::ADMIN_STATIC_TOP_CODE,
			array(
				'#CAPTION#'		=> $this->getLang('L_DUPLICATE_BTN'),
				'#FIELD_NAME#'	=> self::FIELD_NAME
			)
		);
	}

	/* --------- Static pages ----------- */

	const PLXADMIN_EDITSTATIQUES_UPDATE_CODE = <<< 'PLXADMIN_EDITSTATIQUES_UPDATE_CODE'
<?php
if(
	!empty($content['selection']) and
	$content['selection'] == '#CLASS#' and
	!empty($content['idStatic'])
) {
	$this->aStats[$static_id]['ordre'] *= 2;
	if(in_array($static_id, $content['idStatic'])) {
		if(empty($newStaticId)) {
			$staticIds = array_keys($this->aStats);
			rsort($staticIds);
			$kzCounter = intval($staticIds[0]);
			unset($staticIds);
		}
		$kzCounter++;
		$newStaticId = str_pad($kzCounter, 3, "0", STR_PAD_LEFT);
		$newStaticPage = $this->aStats[$static_id];
		$newStaticPage['name'] .= date(' (Y-m-d H:i)');
		$newStaticPage['url'] = plxUtils::title2url($newStaticPage['name']);
		$src = PLX_ROOT.$this->aConf['racine_statiques'].$static_id.'.'.$this->aStats[$static_id]['url'].'.php';
		$target = PLX_ROOT.$this->aConf['racine_statiques'].$newStaticId.'.'.$newStaticPage['url'].'.php';
		if(copy($src, $target)) {
			$kzDate = date('YmdHi');
			$newStaticPage['date_creation'] = $kzDate;
			$newStaticPage['date_update'] = $kzDate;
			$newStaticPage['ordre']++;
			$this->aStats[$newStaticId] = $newStaticPage;
		}
	}
}
?>
PLXADMIN_EDITSTATIQUES_UPDATE_CODE;

	public function plxAdminEditStatiquesUpdate() {
		echo strtr(
			self::PLXADMIN_EDITSTATIQUES_UPDATE_CODE,
			array(
				'#CLASS#'	=> __CLASS__
			)
		);
	}

	const ADMIN_STATICS_TOP_CODE = <<< 'ADMIN_STATICS_TOP_CODE'
<?php
if(!empty($kzStaticDuplicate)) {
	echo preg_replace(
		'@</select>@',
		'<option value="#CLASS#">#CAPTION#</option>'."\n$1",
		ob_get_clean()
	);
}
?>
ADMIN_STATICS_TOP_CODE;

	public function AdminStaticsTop() {
		echo strtr(
			self::ADMIN_STATICS_TOP_CODE,
			array(
				'#CAPTION#'	=> $this->getLang('L_DUPLICATE_BTN'),
				'#CLASS#'	=> __CLASS__
			)
		);
	}

	public function AdminStaticsFoot() {
?>
		<script type="text/javascript">
			(function() {
				'use strict';
				const aForm = document.getElementById('form_statics');
				if(aForm != null && 'submit' in aForm.elements && 'selection' in aForm.elements) {
					aForm.elements.submit.onclick = function(event) {
						const outputs = [
							aForm.elements.selection.selectedOptions[0].textContent + ' :',
							''
						];
						const checkeds = aForm.querySelectorAll('input[name="idStatic[]"]:checked');
						for(var i=0,iMax=checkeds.length; i<iMax; i++) {
							const eltName = checkeds[i].value + '_name';
							if(eltName in aForm.elements) {
								outputs.push(aForm.elements[eltName].value);
							}
						}
						if(confirm(outputs.join("\n"))) {
							if(aForm.elements.selection.value == 'delete') { return true; }
							if(aForm.elements.selection.value == '<?php echo __CLASS__; ?>') {
								aForm.elements.update.click();
							}
						}
						return false;
					};

					aForm.elements.selection.addEventListener('change', function(event) {
						const checkeds = aForm.querySelectorAll('input[name="idStatic[]"]:checked');
						aForm.elements.submit.disabled = (aForm.elements.selection.selectedIndex == 0 || checkeds.length <= 0);
					});

					const aTable = document.getElementById('statics-table');
					if(aTable != null) {
						aForm.elements.submit.disabled = true;
						aTable.addEventListener('change', function(event) {
							if(event.target.tagName == 'INPUT' && event.target.name == 'idStatic[]') {
								const checkeds = aForm.querySelectorAll('input[name="idStatic[]"]:checked');
								aForm.elements.submit.disabled = (aForm.elements.selection.selectedIndex == 0 || checkeds.length <= 0);
								event.preventDefault();
							}
						});
					}
				}

			})();
		</script>
<?php
	}

}
?>
